package com.pixelnetspeed

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat

class SpeedMonitorService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastRxBytes: Long = 0L
    private var lastTxBytes: Long = 0L
    private var lastTimestampMs: Long = 0L

    private val ticker = object : Runnable {
        override fun run() {
            updateSpeed()
            handler.postDelayed(this, INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        lastRxBytes = safeTrafficBytes(TrafficStats.getTotalRxBytes())
        lastTxBytes = safeTrafficBytes(TrafficStats.getTotalTxBytes())
        lastTimestampMs = System.currentTimeMillis()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val initialNotification = buildNotification(0L, 0L)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                initialNotification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, initialNotification)
        }

        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, INTERVAL_MS)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun updateSpeed() {
        val now = System.currentTimeMillis()
        val currentRx = safeTrafficBytes(TrafficStats.getTotalRxBytes())
        val currentTx = safeTrafficBytes(TrafficStats.getTotalTxBytes())

        val elapsedMs = (now - lastTimestampMs).coerceAtLeast(1L)
        val rxDelta = (currentRx - lastRxBytes).coerceAtLeast(0L)
        val txDelta = (currentTx - lastTxBytes).coerceAtLeast(0L)

        lastRxBytes = currentRx
        lastTxBytes = currentTx
        lastTimestampMs = now

        val downBytesPerSec = (rxDelta * 1000L) / elapsedMs
        val upBytesPerSec = (txDelta * 1000L) / elapsedMs

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(downBytesPerSec, upBytesPerSec))

        val broadcast = Intent(ACTION_SPEED_UPDATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_DOWN_BPS, downBytesPerSec)
            putExtra(EXTRA_UP_BPS, upBytesPerSec)
        }
        sendBroadcast(broadcast)
    }

    private fun buildNotification(downBps: Long, upBps: Long): Notification {
        val totalBps = downBps + upBps
        val totalFormatted = SpeedFormatter.formatBytesPerSec(totalBps)
        val downFormatted = SpeedFormatter.formatBytesPerSec(downBps)
        val upFormatted = SpeedFormatter.formatBytesPerSec(upBps)

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val hideZero = Prefs.isHideZero(this) && totalBps < 1024L
        val channelId = if (hideZero) CHANNEL_ID_HIDDEN else CHANNEL_ID_VISIBLE
        val iconBitmap = SpeedFormatter.createStatusBarIconBitmap(totalFormatted)

        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(IconCompat.createWithBitmap(iconBitmap))
            .setContentTitle("Скорость: ${totalFormatted.asSingleLine()}")
            .setContentText("↓ ${downFormatted.asSingleLine()}   ↑ ${upFormatted.asSingleLine()}")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setPriority(if (hideZero) NotificationCompat.PRIORITY_MIN else NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setContentIntent(openAppIntent)
            .build()
    }

    private fun createNotificationChannels() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val visibleChannel = NotificationChannel(
            CHANNEL_ID_VISIBLE,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.channel_desc)
            setShowBadge(false)
            enableLights(false)
            enableVibration(false)
            setSound(null, null)
        }
        val hiddenChannel = NotificationChannel(
            CHANNEL_ID_HIDDEN,
            getString(R.string.channel_hidden_name),
            NotificationManager.IMPORTANCE_MIN
        ).apply {
            description = getString(R.string.channel_hidden_desc)
            setShowBadge(false)
            enableLights(false)
            enableVibration(false)
            setSound(null, null)
        }
        manager.createNotificationChannel(visibleChannel)
        manager.createNotificationChannel(hiddenChannel)
    }

    private fun safeTrafficBytes(value: Long): Long =
        if (value == TrafficStats.UNSUPPORTED.toLong() || value < 0L) 0L else value

    companion object {
        private const val CHANNEL_ID_VISIBLE = "pixel_netspeed_channel"
        private const val CHANNEL_ID_HIDDEN = "pixel_netspeed_channel_hidden"
        private const val NOTIFICATION_ID = 1001
        private const val INTERVAL_MS = 1000L

        const val ACTION_SPEED_UPDATE = "com.pixelnetspeed.SPEED_UPDATE"
        const val EXTRA_DOWN_BPS = "down_bps"
        const val EXTRA_UP_BPS = "up_bps"

        fun start(context: Context) {
            val intent = Intent(context, SpeedMonitorService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, SpeedMonitorService::class.java))
        }
    }
}
