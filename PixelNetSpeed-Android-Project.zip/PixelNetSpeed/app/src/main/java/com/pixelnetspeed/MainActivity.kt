package com.pixelnetspeed

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var tvDownloadSpeed: TextView
    private lateinit var tvUploadSpeed: TextView
    private lateinit var switchEnable: MaterialSwitch
    private lateinit var switchAutostart: MaterialSwitch
    private lateinit var switchHideZero: MaterialSwitch

    private val speedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val down = intent.getLongExtra(SpeedMonitorService.EXTRA_DOWN_BPS, 0L)
            val up = intent.getLongExtra(SpeedMonitorService.EXTRA_UP_BPS, 0L)
            tvDownloadSpeed.text = SpeedFormatter.formatBytesPerSec(down).asSingleLine()
            tvUploadSpeed.text = SpeedFormatter.formatBytesPerSec(up).asSingleLine()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            enableIndicator(true)
        } else {
            switchEnable.isChecked = false
            Toast.makeText(this, R.string.permission_needed, Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvDownloadSpeed = findViewById(R.id.tvDownloadSpeed)
        tvUploadSpeed = findViewById(R.id.tvUploadSpeed)
        switchEnable = findViewById(R.id.switchEnable)
        switchAutostart = findViewById(R.id.switchAutostart)
        switchHideZero = findViewById(R.id.switchHideZero)
        val btnBatterySettings: MaterialButton = findViewById(R.id.btnBatterySettings)

        switchEnable.isChecked = Prefs.isEnabled(this)
        switchAutostart.isChecked = Prefs.isAutostart(this)
        switchHideZero.isChecked = Prefs.isHideZero(this)

        switchEnable.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (hasNotificationPermission()) {
                    enableIndicator(true)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            } else {
                enableIndicator(false)
            }
        }

        switchAutostart.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setAutostart(this, isChecked)
        }

        switchHideZero.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setHideZero(this, isChecked)
        }

        btnBatterySettings.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        }

        if (Prefs.isEnabled(this) && hasNotificationPermission()) {
            SpeedMonitorService.start(this)
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(SpeedMonitorService.ACTION_SPEED_UPDATE)
        ContextCompat.registerReceiver(
            this,
            speedReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        unregisterReceiver(speedReceiver)
        super.onStop()
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun enableIndicator(enabled: Boolean) {
        Prefs.setEnabled(this, enabled)
        if (enabled) {
            SpeedMonitorService.start(this)
        } else {
            SpeedMonitorService.stop(this)
            tvDownloadSpeed.text = "0 KB/s"
            tvUploadSpeed.text = "0 KB/s"
        }
    }
}
