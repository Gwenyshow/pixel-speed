package com.pixelnetspeed

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED
        ) {
            if (Prefs.isEnabled(context) && Prefs.isAutostart(context)) {
                try {
                    SpeedMonitorService.start(context)
                } catch (_: Exception) {
                    // Android may restrict background foreground-service start until first unlock
                }
            }
        }
    }
}
