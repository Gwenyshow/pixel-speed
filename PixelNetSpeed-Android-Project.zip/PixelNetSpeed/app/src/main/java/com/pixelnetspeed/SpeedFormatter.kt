package com.pixelnetspeed

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import java.util.Locale

data class FormattedSpeed(
    val valueText: String,
    val unitText: String
) {
    fun asSingleLine(): String = "$valueText $unitText"
}

object SpeedFormatter {

    fun formatBytesPerSec(bytesPerSec: Long): FormattedSpeed {
        val safeBytes = if (bytesPerSec < 0) 0L else bytesPerSec
        val kb = safeBytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0

        return when {
            gb >= 1.0 -> FormattedSpeed(
                valueText = String.format(Locale.US, "%.1f", gb),
                unitText = "GB/s"
            )
            mb >= 100.0 -> FormattedSpeed(
                valueText = String.format(Locale.US, "%.0f", mb),
                unitText = "MB/s"
            )
            mb >= 10.0 -> FormattedSpeed(
                valueText = String.format(Locale.US, "%.1f", mb),
                unitText = "MB/s"
            )
            mb >= 1.0 -> FormattedSpeed(
                valueText = String.format(Locale.US, "%.2f", mb),
                unitText = "MB/s"
            )
            kb >= 10.0 -> FormattedSpeed(
                valueText = String.format(Locale.US, "%.0f", kb),
                unitText = "KB/s"
            )
            kb >= 1.0 -> FormattedSpeed(
                valueText = String.format(Locale.US, "%.1f", kb),
                unitText = "KB/s"
            )
            else -> FormattedSpeed(
                valueText = "0",
                unitText = "KB/s"
            )
        }
    }

    /**
     * Renders a crisp two-line monochrome white bitmap (value on top, unit below)
     * suitable for Android status bar notification small icons on Pixel devices.
     */
    fun createStatusBarIconBitmap(speed: FormattedSpeed): Bitmap {
        val size = 96
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = when {
                speed.valueText.length <= 2 -> 54f
                speed.valueText.length == 3 -> 46f
                else -> 38f
            }
        }

        val unitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 30f
        }

        val cx = size / 2f
        canvas.drawText(speed.valueText, cx, 50f, valuePaint)
        canvas.drawText(speed.unitText, cx, 88f, unitPaint)
        return bitmap
    }
}
