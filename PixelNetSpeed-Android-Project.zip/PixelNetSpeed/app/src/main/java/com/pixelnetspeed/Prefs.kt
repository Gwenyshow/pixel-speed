package com.pixelnetspeed

import android.content.Context

object Prefs {
    private const val NAME = "pixel_netspeed_prefs"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_AUTOSTART = "autostart"
    private const val KEY_HIDE_ZERO = "hide_zero"

    private fun sp(context: Context) =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun isEnabled(context: Context): Boolean = sp(context).getBoolean(KEY_ENABLED, false)
    fun setEnabled(context: Context, value: Boolean) {
        sp(context).edit().putBoolean(KEY_ENABLED, value).apply()
    }

    fun isAutostart(context: Context): Boolean = sp(context).getBoolean(KEY_AUTOSTART, true)
    fun setAutostart(context: Context, value: Boolean) {
        sp(context).edit().putBoolean(KEY_AUTOSTART, value).apply()
    }

    fun isHideZero(context: Context): Boolean = sp(context).getBoolean(KEY_HIDE_ZERO, false)
    fun setHideZero(context: Context, value: Boolean) {
        sp(context).edit().putBoolean(KEY_HIDE_ZERO, value).apply()
    }
}
