package com.pixelnetspeed

import java.util.Locale

object SpeedFormatter {

    fun formatCompact(bytesPerSec: Long): String {
        val safeBytes = if (bytesPerSec < 0) 0L else bytesPerSec
        val kb = safeBytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0

        return when {
            gb >= 1.0 -> String.format(Locale.US, "%.1f GB/s", gb)
            mb >= 10.0 -> String.format(Locale.US, "%.1f MB/s", mb)
            mb >= 1.0 -> String.format(Locale.US, "%.2f MB/s", mb)
            kb >= 10.0 -> String.format(Locale.US, "%.0f KB/s", kb)
            kb >= 1.0 -> String.format(Locale.US, "%.1f KB/s", kb)
            else -> "0 KB/s"
        }
    }
}
