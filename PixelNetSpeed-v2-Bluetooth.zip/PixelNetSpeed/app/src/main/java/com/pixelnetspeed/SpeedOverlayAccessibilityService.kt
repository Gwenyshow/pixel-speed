package com.pixelnetspeed

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import androidx.core.content.ContextCompat

class SpeedOverlayAccessibilityService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var speedTextView: TextView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private var lastRxBytes: Long = 0L
    private var lastTxBytes: Long = 0L
    private var lastTimestampMs: Long = 0L

    private val configReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            applyLayoutConfig()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateSpeed()
            handler.postDelayed(this, INTERVAL_MS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true

        lastRxBytes = safeTrafficBytes(TrafficStats.getTotalRxBytes())
        lastTxBytes = safeTrafficBytes(TrafficStats.getTotalTxBytes())
        lastTimestampMs = System.currentTimeMillis()

        createOverlay()

        val filter = IntentFilter(ACTION_CONFIG_CHANGED)
        ContextCompat.registerReceiver(
            this,
            configReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, INTERVAL_MS)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed; service only displays the status bar overlay
    }

    override fun onInterrupt() {
        // Nothing to interrupt
    }

    override fun onDestroy() {
        isRunning = false
        handler.removeCallbacks(ticker)
        try {
            unregisterReceiver(configReceiver)
        } catch (_: Exception) {
        }
        removeOverlay()
        super.onDestroy()
    }

    private fun createOverlay() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val tv = TextView(this).apply {
            text = "0 KB/s"
            setTextColor(Color.WHITE)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setShadowLayer(2f, 0f, 1f, Color.argb(160, 0, 0, 0))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, Prefs.getTextSizeSp(this@SpeedOverlayAccessibilityService).toFloat())
            includeFontPadding = false
        }

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dpToPx(Prefs.getOffsetXDp(this@SpeedOverlayAccessibilityService))
            y = dpToPx(Prefs.getOffsetYDp(this@SpeedOverlayAccessibilityService))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        speedTextView = tv
        layoutParams = params
        try {
            windowManager?.addView(tv, params)
        } catch (_: Exception) {
        }
    }

    private fun applyLayoutConfig() {
        val tv = speedTextView ?: return
        val params = layoutParams ?: return
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, Prefs.getTextSizeSp(this).toFloat())
        params.x = dpToPx(Prefs.getOffsetXDp(this))
        params.y = dpToPx(Prefs.getOffsetYDp(this))
        try {
            windowManager?.updateViewLayout(tv, params)
        } catch (_: Exception) {
        }
    }

    private fun removeOverlay() {
        val tv = speedTextView ?: return
        try {
            windowManager?.removeView(tv)
        } catch (_: Exception) {
        }
        speedTextView = null
        layoutParams = null
    }

    private fun updateSpeed() {
        val now = System.currentTimeMillis()
        val currentRx = safeTrafficBytes(TrafficStats.getTotalRxBytes())
        val currentTx = safeTrafficBytes(TrafficStats.getTotalTxBytes())

        val elapsedMs = (now - lastTimestampMs).coerceAtLeast(1L)
        val rxDelta = (currentRx - lastRxBytes).coerceAtLeast(0L)
        val txDelta = (currentTx - lastTxBytes).coerceAtLeast(0L)

        lastRxBytes = currentRx
        lastTxBytes = currentTx
        lastTimestampMs = now

        val downBps = (rxDelta * 1000L) / elapsedMs
        val upBps = (txDelta * 1000L) / elapsedMs
        val totalBps = downBps + upBps

        val tv = speedTextView
        if (tv != null) {
            if (Prefs.isHideZero(this) && totalBps < 1024L) {
                tv.visibility = View.INVISIBLE
            } else {
                tv.visibility = View.VISIBLE
                tv.text = SpeedFormatter.formatCompact(totalBps)
            }
        }

        val broadcast = Intent(ACTION_SPEED_UPDATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_DOWN_BPS, downBps)
            putExtra(EXTRA_UP_BPS, upBps)
        }
        sendBroadcast(broadcast)
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun safeTrafficBytes(value: Long): Long =
        if (value == TrafficStats.UNSUPPORTED.toLong() || value < 0L) 0L else value

    companion object {
        private const val INTERVAL_MS = 1000L
        const val ACTION_CONFIG_CHANGED = "com.pixelnetspeed.OVERLAY_CONFIG_CHANGED"
        const val ACTION_SPEED_UPDATE = "com.pixelnetspeed.SPEED_UPDATE"
        const val EXTRA_DOWN_BPS = "down_bps"
        const val EXTRA_UP_BPS = "up_bps"

        @Volatile
        var isRunning: Boolean = false
            private set
    }
}
