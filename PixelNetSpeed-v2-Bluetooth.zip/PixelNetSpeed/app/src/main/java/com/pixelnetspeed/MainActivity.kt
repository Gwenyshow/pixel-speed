package com.pixelnetspeed

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvDownloadSpeed: TextView
    private lateinit var tvUploadSpeed: TextView
    private lateinit var tvOffsetXLabel: TextView
    private lateinit var tvOffsetYLabel: TextView
    private lateinit var tvTextSizeLabel: TextView

    private val speedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val down = intent.getLongExtra(SpeedOverlayAccessibilityService.EXTRA_DOWN_BPS, 0L)
            val up = intent.getLongExtra(SpeedOverlayAccessibilityService.EXTRA_UP_BPS, 0L)
            tvDownloadSpeed.text = SpeedFormatter.formatCompact(down)
            tvUploadSpeed.text = SpeedFormatter.formatCompact(up)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvDownloadSpeed = findViewById(R.id.tvDownloadSpeed)
        tvUploadSpeed = findViewById(R.id.tvUploadSpeed)
        tvOffsetXLabel = findViewById(R.id.tvOffsetXLabel)
        tvOffsetYLabel = findViewById(R.id.tvOffsetYLabel)
        tvTextSizeLabel = findViewById(R.id.tvTextSizeLabel)

        val btnOpenAccessibility: MaterialButton = findViewById(R.id.btnOpenAccessibility)
        val btnOpenAppInfo: MaterialButton = findViewById(R.id.btnOpenAppInfo)
        val seekOffsetX: SeekBar = findViewById(R.id.seekOffsetX)
        val seekOffsetY: SeekBar = findViewById(R.id.seekOffsetY)
        val seekTextSize: SeekBar = findViewById(R.id.seekTextSize)
        val switchHideZero: MaterialSwitch = findViewById(R.id.switchHideZero)

        val currentX = Prefs.getOffsetXDp(this)
        val currentY = Prefs.getOffsetYDp(this)
        val currentSize = Prefs.getTextSizeSp(this)

        seekOffsetX.progress = currentX
        seekOffsetY.progress = currentY
        seekTextSize.progress = (currentSize - 9).coerceIn(0, 8)
        switchHideZero.isChecked = Prefs.isHideZero(this)

        updateLabels(currentX, currentY, currentSize)

        btnOpenAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnOpenAppInfo.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        }

        seekOffsetX.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                Prefs.setOffsetXDp(this@MainActivity, progress)
                updateLabels(progress, Prefs.getOffsetYDp(this@MainActivity), Prefs.getTextSizeSp(this@MainActivity))
                notifyConfigChanged()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        seekOffsetY.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                Prefs.setOffsetYDp(this@MainActivity, progress)
                updateLabels(Prefs.getOffsetXDp(this@MainActivity), progress, Prefs.getTextSizeSp(this@MainActivity))
                notifyConfigChanged()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        seekTextSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val sp = progress + 9
                Prefs.setTextSizeSp(this@MainActivity, sp)
                updateLabels(Prefs.getOffsetXDp(this@MainActivity), Prefs.getOffsetYDp(this@MainActivity), sp)
                notifyConfigChanged()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        switchHideZero.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setHideZero(this, isChecked)
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(SpeedOverlayAccessibilityService.ACTION_SPEED_UPDATE)
        ContextCompat.registerReceiver(
            this,
            speedReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onResume() {
        super.onResume()
        tvStatus.text = if (SpeedOverlayAccessibilityService.isRunning) {
            getString(R.string.status_active)
        } else {
            getString(R.string.status_inactive)
        }
    }

    override fun onStop() {
        unregisterReceiver(speedReceiver)
        super.onStop()
    }

    private fun updateLabels(x: Int, y: Int, sizeSp: Int) {
        tvOffsetXLabel.text = "${getString(R.string.label_offset_x)}: ${x} dp"
        tvOffsetYLabel.text = "${getString(R.string.label_offset_y)}: ${y} dp"
        tvTextSizeLabel.text = "${getString(R.string.label_text_size)}: ${sizeSp} sp"
    }

    private fun notifyConfigChanged() {
        val intent = Intent(SpeedOverlayAccessibilityService.ACTION_CONFIG_CHANGED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }
}
