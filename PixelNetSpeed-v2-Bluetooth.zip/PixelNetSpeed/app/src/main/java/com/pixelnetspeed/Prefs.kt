package com.pixelnetspeed

import android.content.Context

object Prefs {
    private const val NAME = "pixel_netspeed_prefs"
    private const val KEY_OFFSET_X = "offset_x_dp"
    private const val KEY_OFFSET_Y = "offset_y_dp"
    private const val KEY_TEXT_SIZE = "text_size_sp"
    private const val KEY_HIDE_ZERO = "hide_zero"

    private fun sp(context: Context) =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getOffsetXDp(context: Context): Int = sp(context).getInt(KEY_OFFSET_X, 145)
    fun setOffsetXDp(context: Context, value: Int) {
        sp(context).edit().putInt(KEY_OFFSET_X, value).apply()
    }

    fun getOffsetYDp(context: Context): Int = sp(context).getInt(KEY_OFFSET_Y, 10)
    fun setOffsetYDp(context: Context, value: Int) {
        sp(context).edit().putInt(KEY_OFFSET_Y, value).apply()
    }

    fun getTextSizeSp(context: Context): Int = sp(context).getInt(KEY_TEXT_SIZE, 12)
    fun setTextSizeSp(context: Context, value: Int) {
        sp(context).edit().putInt(KEY_TEXT_SIZE, value).apply()
    }

    fun isHideZero(context: Context): Boolean = sp(context).getBoolean(KEY_HIDE_ZERO, false)
    fun setHideZero(context: Context, value: Boolean) {
        sp(context).edit().putBoolean(KEY_HIDE_ZERO, value).apply()
    }
}
